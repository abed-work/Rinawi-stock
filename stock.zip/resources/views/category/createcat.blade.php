@extends('products.layout')

@section('content')

@endsection
