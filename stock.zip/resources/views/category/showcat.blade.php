@extends('products.layout')

@section('content')
<h1> hello </h1>
@endsection
